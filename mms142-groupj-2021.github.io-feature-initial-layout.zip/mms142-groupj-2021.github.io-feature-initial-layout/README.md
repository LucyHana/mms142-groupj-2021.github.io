# Disruptive Technology: Digital Wallet

## MMS 142

## Group J Members
- Leann Nicole Rabang
- Christian Reynold Pelejo
- Christine Faye Pesimo
- Justine Hannah Plaza
- Alyanna Regina Quiray
- Carlos Gabriel Quetua
- Cesar III Ramos
- Mica Mierra Papna (unresponsive)
- Maria Elisa Pineda (unresponsive)
